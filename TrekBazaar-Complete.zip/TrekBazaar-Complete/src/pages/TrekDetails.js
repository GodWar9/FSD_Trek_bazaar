import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { TREKS } from '../data/treks';

export default function TrekDetails() {
  const { id } = useParams();
  const trek = TREKS.find((t) => t.id === id);

  if (!trek) {
    return (
      <div className="container" style={{ padding: '60px 20px', textAlign: 'center' }}>
        <h2>Trek Not Found</h2>
        <p style={{ margin: '15px 0' }}>The specified trek route could not be located.</p>
        <Link to="/treks" className="btn">Back to All Treks</Link>
      </div>
    );
  }

  return (
    <div className="container" style={{ padding: '40px 20px' }}>
      <Link to="/treks" style={{ color: '#2e7d32', fontWeight: 'bold' }}>← Back to All Treks</Link>
      <div style={{ marginTop: '20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', background: '#fff', padding: '30px', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.06)' }}>
        <img src={trek.image} alt={trek.title} style={{ width: '100%', borderRadius: '8px', maxHeight: '400px', objectFit: 'cover' }} />
        <div>
          <span className="badge">{trek.difficulty}</span>
          <h1 style={{ color: '#1b4332', margin: '10px 0' }}>{trek.title}</h1>
          <p style={{ fontSize: '1.1rem', color: '#666', marginBottom: '15px' }}>📍 {trek.location} | ⏳ {trek.duration}</p>
          <p style={{ lineHeight: '1.6', marginBottom: '20px' }}>{trek.description}</p>
          <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#2e7d32', marginBottom: '20px' }}>Price: {trek.price}</div>
          <button className="btn" style={{ padding: '12px 30px', fontSize: '1rem' }} onClick={() => alert(`Booking initiated for ${trek.title}!`)}>Book Expedition Now</button>
        </div>
      </div>
    </div>
  );
}