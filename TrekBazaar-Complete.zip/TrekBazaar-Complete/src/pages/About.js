import React from 'react';

export default function About() {
  return (
    <div className="container" style={{ padding: '40px 20px' }}>
      <h1 style={{ color: '#1b4332', marginBottom: '15px' }}>About TrekBazaar</h1>
      <p style={{ fontSize: '1.1rem', lineHeight: '1.7', color: '#444', marginBottom: '25px' }}>
        TrekBazaar connects outdoor enthusiasts with verified trekking guides, high-quality gear rentals, and detailed trail maps across the world.
      </p>
      <img src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80" alt="TrekBazaar Expedition" style={{ width: '100%', maxHeight: '350px', objectFit: 'cover', borderRadius: '8px' }} />
    </div>
  );
}