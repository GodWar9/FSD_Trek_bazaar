import React from 'react';
import { Link } from 'react-router-dom';
import { TREKS } from '../data/treks';
import './Home.css';

export default function Home() {
  return (
    <div className="home-page">
      <section className="hero">
        <div className="hero-content">
          <h1>Discover Your Next Mountain Adventure</h1>
          <p>Curated trekking itineraries, expert trail guides, and premium gear.</p>
          <Link to="/treks" className="btn hero-btn">Explore All Treks</Link>
        </div>
      </section>

      <section className="featured container">
        <h2>Featured Treks</h2>
        <div className="trek-grid">
          {TREKS.map((trek) => (
            <div key={trek.id} className="trek-card">
              <img src={trek.image} alt={trek.title} />
              <div className="trek-info">
                <span className="badge">{trek.difficulty}</span>
                <h3>{trek.title}</h3>
                <p className="meta">📍 {trek.location} • ⏳ {trek.duration}</p>
                <div className="card-footer">
                  <span className="price">{trek.price}</span>
                  <Link to={`/treks/${trek.id}`} className="btn">View Details</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}