import React from 'react';
import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="container" style={{ padding: '60px 20px', textAlign: 'center' }}>
      <h1>404 - Page Not Found</h1>
      <p style={{ margin: '15px 0' }}>The requested page does not exist.</p>
      <Link to="/" className="btn">Return Home</Link>
    </div>
  );
}