import React from 'react';
import { Link } from 'react-router-dom';
import { TREKS } from '../data/treks';

export default function TrekList() {
  return (
    <div className="container" style={{ padding: '40px 20px' }}>
      <h1 style={{ color: '#1b4332', marginBottom: '10px' }}>All Trekking Expeditions</h1>
      <p style={{ color: '#666', marginBottom: '30px' }}>Select a trail to view full itinerary and booking requirements.</p>
      
      <div className="trek-grid">
        {TREKS.map((trek) => (
          <div key={trek.id} className="trek-card">
            <img src={trek.image} alt={trek.title} />
            <div className="trek-info">
              <span className="badge">{trek.difficulty}</span>
              <h3>{trek.title}</h3>
              <p className="meta">📍 {trek.location} • ⏳ {trek.duration}</p>
              <p style={{ fontSize: '0.9rem', color: '#555', marginBottom: '15px' }}>{trek.description}</p>
              <div className="card-footer">
                <span className="price">{trek.price}</span>
                <Link to={`/treks/${trek.id}`} className="btn">Explore Route</Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}