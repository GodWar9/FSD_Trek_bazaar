import React from 'react';

export default function Footer() {
  return (
    <footer style={{ background: '#081c15', color: '#b7e4c7', padding: '30px 0', marginTop: '50px', textAlign: 'center' }}>
      <div className="container">
        <p>&copy; {new Date().getFullYear()} TrekBazaar. All rights reserved.</p>
        <p style={{ fontSize: '0.85rem', marginTop: '8px', color: '#74c69d' }}>Connecting adventurers to legendary trails worldwide.</p>
      </div>
    </footer>
  );
}