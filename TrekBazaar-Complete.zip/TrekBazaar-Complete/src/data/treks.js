export const TREKS = [
  {
    id: "1",
    title: "Everest Base Camp Trek",
    location: "Nepal",
    duration: "14 Days",
    difficulty: "Challenging",
    price: "$1,450",
    image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80",
    description: "Experience the pinnacle of high-altitude trekking through legendary Sherpa villages to the foot of Mount Everest."
  },
  {
    id: "2",
    title: "Inca Trail to Machu Picchu",
    location: "Peru",
    duration: "4 Days",
    difficulty: "Moderate",
    price: "$890",
    image: "https://images.unsplash.com/photo-1526392060635-9d6019884377?auto=format&fit=crop&w=800&q=80",
    description: "Hike ancient stone pathways through cloud forests ending at the sacred Sun Gate of Machu Picchu."
  },
  {
    id: "3",
    title: "Tour du Mont Blanc",
    location: "France / Italy / Switzerland",
    duration: "10 Days",
    difficulty: "Moderate to Strenuous",
    price: "$1,200",
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80",
    description: "Circle Western Europe's highest peak across three country borders with breathtaking alpine panoramas."
  },
  {
    id: "4",
    title: "Kilimanjaro Machame Route",
    location: "Tanzania",
    duration: "7 Days",
    difficulty: "Strenuous",
    price: "$1,850",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
    description: "Ascend Africa's highest summit through rainforests, moorlands, and volcanic desert peaks."
  }
];